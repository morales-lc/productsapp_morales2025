// =================== HOMESCREEN ===================
// Main home screen for the products app. Handles product listing, categories, search, navigation, and user info.
// Uses Provider for theme and language, and manages state for products and categories.
// Contains all main sections: search, banners, product lists, categories, recommendations, trending, and hot deals.
// Also handles navigation to product details, category screens, and logout logic.
//
// Author: [Your Name]
// Date: [Today's Date]
//
// =================== IMPORTS ===================
import 'dart:math';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'addproduct.dart';
import 'models/background_model.dart';
import 'models/language_model.dart';
import 'login.dart';
import 'myproduct_screen.dart';
import 'productinfo.dart';
import 'settings.dart';
import 'package:provider/provider.dart';
import 'config.dart';
import 'category_products_screen.dart';
import 'search_result_screen.dart';

class HomeScreen extends StatefulWidget {
  /// Main entry point for the home page of the app.
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // List of all products fetched from the API
  List<Map<String, dynamic>> allProducts = [];
  // List of all categories fetched from the API
  List<Map<String, dynamic>> categories = [];
  // Loading state for the home screen
  bool isLoading = true;
  // User info
  String? userName;
  String? userEmail;
  // Current selected index for bottom navigation
  int _selectedIndex = 0;
  // Search query for filtering products
  final String _searchQuery = '';
  // Controller for the search bar
  final TextEditingController _searchController = TextEditingController();

  // =================== INIT ===================
  @override
  void initState() {
    super.initState();
    loadProducts();
    loadCategories();
    loadUserInfo();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      showWelcomeDialog();
    });
  }

  /// Shows a welcome dialog after login
  void showWelcomeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Welcome!"),
        content: Text("You have successfully logged in."),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  /// Loads all products from the API
  Future<void> loadProducts() async {
    try {
      final response =
          await http.get(Uri.parse('${AppConfig.baseUrl}/api/products?all=1'));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final raw = jsonData['data'] ?? jsonData;
        List<Map<String, dynamic>> fetched =
            List<Map<String, dynamic>>.from(raw);
        fetched.shuffle(Random());

        setState(() {
          allProducts = fetched;
          isLoading = false;
        });
      }
    } catch (e) {
      //print('Failed to load products: $e');
      setState(() => isLoading = false);
    }
  }

  /// Loads all categories from the API
  Future<void> loadCategories() async {
    try {
      final response =
          await http.get(Uri.parse('${AppConfig.baseUrl}/api/categories'));
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() {
          categories = data
              .map<Map<String, dynamic>>((item) => {
                    'id': item['id'],
                    'name': item['name'],
                    'image_path': item['image_path'],
                  })
              .toList();
        });
      }
    } catch (e) {
      //print('Failed to load categories: $e');
    }
  }

  /// Loads user info from shared preferences
  Future<void> loadUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userEmail = prefs.getString('user_email') ?? 'user@example.com';
    });
  }

  // =================== UI WIDGETS ===================

  /// Horizontal product list for sections like Best Sellers, New Arrivals, etc.
  Widget productList(List<Map<String, dynamic>> items, {Set<int>? excludeIds}) {
    return SizedBox(
      height: 210, // Increased from 200 to 210 to prevent bottom overflow
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) {
          final product = items[index];
          if (excludeIds != null && excludeIds.contains(product['id'])) {
            return SizedBox.shrink(); // Skip duplicates
          }
          final hasImage = product['image_path'] != null &&
              product['image_path'].toString().isNotEmpty;
          final imageWidget = hasImage &&
                  !product['image_path']
                      .toString()
                      .toLowerCase()
                      .endsWith('.asset')
              ? Image.network(
                  '${AppConfig.baseUrl}/storage/${product['image_path']}',
                  height: 100,
                  width: 130,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Image.asset(
                      'assets/product_placeholder.png',
                      height: 100,
                      width: 130,
                      fit: BoxFit.cover),
                )
              : Image.asset('assets/product_placeholder.png',
                  height: 100, width: 130, fit: BoxFit.cover);
          return Padding(
            padding: EdgeInsets.only(right: 10),
            child: GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProductDetailsScreen(product: product)),
              ),
              child: ProductItem(
                imageWidget: imageWidget,
                name: product['name']?.toString() ?? '',
                description: product['description']?.toString() ?? '',
                price: '₱${product['price']?.toString() ?? ''}',
              ),
            ),
          );
        },
      ),
    );
  }

  /// Grid of recommended products (2x2)
  Widget recommendedGrid(List<Map<String, dynamic>> items) {
    final random = Random();
    final recommended = List<Map<String, dynamic>>.from(items)..shuffle(random);
    final recs = recommended.take(4).toList();
    return Column(
      children: [
        Row(
          children: [
            Expanded(
                child: GestureDetector(
              onTap: () => _navigateToProductInfo(recs, 0),
              child: RecommendedProductItem(
                  imagePath: getProductImage(recs, 0),
                  price: getProductPrice(recs, 0),
                  name: getProductName(recs, 0),
                  description: getProductDesc(recs, 0)),
            )),
            SizedBox(width: 10),
            Expanded(
                child: GestureDetector(
              onTap: () => _navigateToProductInfo(recs, 1),
              child: RecommendedProductItem(
                  imagePath: getProductImage(recs, 1),
                  price: getProductPrice(recs, 1),
                  name: getProductName(recs, 1),
                  description: getProductDesc(recs, 1)),
            )),
          ],
        ),
        SizedBox(height: 10),
        Row(
          children: [
            Expanded(
                child: GestureDetector(
              onTap: () => _navigateToProductInfo(recs, 2),
              child: RecommendedProductItem(
                  imagePath: getProductImage(recs, 2),
                  price: getProductPrice(recs, 2),
                  name: getProductName(recs, 2),
                  description: getProductDesc(recs, 2)),
            )),
            SizedBox(width: 10),
            Expanded(
                child: GestureDetector(
              onTap: () => _navigateToProductInfo(recs, 3),
              child: RecommendedProductItem(
                  imagePath: getProductImage(recs, 3),
                  price: getProductPrice(recs, 3),
                  name: getProductName(recs, 3),
                  description: getProductDesc(recs, 3)),
            )),
          ],
        ),
      ],
    );
  }

  /// Gets the image URL or placeholder for a product
  String getProductImage(List<Map<String, dynamic>> list, int idx) {
    if (idx >= list.length) return 'assets/product_placeholder.png';
    final p = list[idx];
    if (p['image_path'] != null && p['image_path'].toString().isNotEmpty) {
      return '${AppConfig.baseUrl}/storage/${p['image_path']}';
    }
    return 'assets/product_placeholder.png';
  }

  /// Gets the price string for a product
  String getProductPrice(List<Map<String, dynamic>> list, int idx) {
    if (idx >= list.length) return '';
    return '₱${list[idx]['price']?.toString() ?? ''}';
  }

  /// Gets the name for a product
  String getProductName(List<Map<String, dynamic>> list, int idx) {
    if (idx >= list.length) return '';
    return list[idx]['name']?.toString() ?? '';
  }

  /// Gets the description for a product
  String getProductDesc(List<Map<String, dynamic>> list, int idx) {
    if (idx >= list.length) return '';
    return list[idx]['description']?.toString() ?? '';
  }

  /// Navigates to the product info screen for a given product
  void _navigateToProductInfo(List<Map<String, dynamic>> list, int idx) {
    if (idx >= list.length) return;
    final product = list[idx];
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductDetailsScreen(product: product),
      ),
    );
  }

  /// Section for trending products
  Widget trendingProductsSection(List<Map<String, dynamic>> items) {
    final random = Random();
    final trending = List<Map<String, dynamic>>.from(items)..shuffle(random);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        sectionTitle('Trending Products'),
        productList(trending.take(8).toList()),
      ],
    );
  }

  /// Section for hot deals
  Widget hotDealsSection(List<Map<String, dynamic>> items) {
    final random = Random();
    final hotDeals = List<Map<String, dynamic>>.from(items)..shuffle(random);
    final recs = hotDeals.take(4).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        sectionTitle('Hot Deals'),
        recommendedGrid(recs),
      ],
    );
  }

  /// Main body builder for the home screen
  Widget _getBody() {
    switch (_selectedIndex) {
      case 0:
        return _buildHomeBody();
      case 1:
        return FutureBuilder<int?>(
          future: _getUserId(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            }
            final userId = snapshot.data;
            if (userId == null) {
              return Center(child: Text("No user logged in."));
            }
            return MyProductsScreen(userId: userId);
          },
        );
      case 2:
        return SettingsScreen();
      default:
        return _buildHomeBody();
    }
  }

  /// Gets the user ID from shared preferences
  Future<int?> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('user_id');
  }

  /// Builds the main home body with all sections
  Widget _buildHomeBody() {
    final isFilipino = Provider.of<LanguageModel>(context).isFilipino();
    final backgroundModel = Provider.of<Backgroundmodel>(context);
    int split = (allProducts.length / 2).ceil();

    return isLoading
        ? Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: () async {
              await loadProducts();
              await loadCategories();
              await loadUserInfo();
            },
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),
                  // --- Search Bar ---
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            decoration: InputDecoration(
                              hintText: isFilipino
                                  ? "Maghanap ng produkto..."
                                  : "Search products...",
                              prefixIcon: Icon(Icons.search),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: EdgeInsets.symmetric(vertical: 0),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Colors.grey.shade300),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Colors.grey.shade300),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide: BorderSide(
                                    color: backgroundModel.accent, width: 2),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 8),
                        Material(
                          color: backgroundModel.accent,
                          shape: CircleBorder(),
                          child: IconButton(
                            icon:
                                Icon(Icons.arrow_forward, color: Colors.white),
                            onPressed: () {
                              final query = _searchController.text.trim();
                              if (query.isNotEmpty) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SearchResultScreen(
                                      query: query,
                                      allProducts: allProducts,
                                      categories: categories,
                                    ),
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  // --- Banner ---
                  SizedBox(
                    height: 220,
                    child: PageView(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Image.asset("assets/banner.jpg",
                              width: double.infinity, fit: BoxFit.cover),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Image.asset("assets/laptop.jpg",
                              width: double.infinity, fit: BoxFit.cover),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Image.asset("assets/smartwatch.jpg",
                              width: double.infinity, fit: BoxFit.cover),
                        ),
                        // Add more banners as needed
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  sectionTitle(isFilipino ? "Mga Produkto" : "Products"),
                  productList(
                    allProducts.take(split).toList(),
                  ),
                  sectionTitleWithAction(
                    isFilipino ? "Pinakamabenta" : "Best Seller",
                    isFilipino ? "Ipakita lahat >" : "See all >",
                  ),
                  productList(
                    allProducts.skip(split).toList(),
                  ),
                  sectionTitle(isFilipino ? "Mga Kategorya" : "Categories"),
                  categoryGrid(),
                  SizedBox(height: 24), // Add spacing before recommended
                  sectionTitle(isFilipino
                      ? "Inirerekomenda para sa iyo"
                      : "Recommended for you"),
                  recommendedGrid(allProducts),
                  SizedBox(height: 24), // Add spacing before trending
                  trendingProductsSection(allProducts),
                  hotDealsSection(allProducts),
                ],
              ),
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    final isFilipino = Provider.of<LanguageModel>(context).isFilipino();
    final backgroundModel = Provider.of<Backgroundmodel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: backgroundModel.appBar,
        elevation: 0,
        actions: [
          Icon(Icons.notifications_none, color: Colors.black),
          SizedBox(width: 15),
          CircleAvatar(backgroundImage: AssetImage("assets/profile.png")),
          SizedBox(width: 15),
          IconButton(
            icon: Icon(Icons.logout, color: Colors.red),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final token = prefs.getString('access_token');
              if (token == null || token.isEmpty) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
                return;
              }
              try {
                final response = await http.post(
                  Uri.parse('${AppConfig.baseUrl}/api/auth/logout'),
                  headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                    'Authorization': 'Bearer $token',
                  },
                );
                if (response.statusCode == 200) {
                  await prefs.remove('access_token');
                  await prefs.remove('user_id');
                  await prefs.remove('user_name');
                  await prefs.remove('user_email');
                  if (!mounted) return;
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                } else {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logout failed.')),
                  );
                }
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Connection error.')),
                );
              }
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: backgroundModel.appBar),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                      backgroundImage: AssetImage("assets/profile.png"),
                      radius: 30),
                  SizedBox(height: 10),
                  Text(userName ?? "User Name",
                      style: TextStyle(fontSize: 18, color: Colors.white)),
                  Text(userEmail ?? "user@example.com",
                      style: TextStyle(fontSize: 14, color: Colors.white70)),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                setState(() => _selectedIndex = 0);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.add_box),
              title: Text(isFilipino ? "Magdagdag ng Produkto" : 'Add Product'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => AddProductScreen())),
            ),
            ListTile(
              leading: Icon(Icons.inventory),
              title: Text(isFilipino ? "Iyong Mga Produkto" : 'My Products'),
              onTap: () async {
                setState(() => _selectedIndex = 1);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
              onTap: () {
                setState(() => _selectedIndex = 2);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text(isFilipino ? "Mag-Logout" : 'Logout'),
              onTap: () async {
                final prefs = await SharedPreferences.getInstance();
                final token = prefs.getString('access_token');
                if (token == null || token.isEmpty) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => LoginScreen()),
                  );
                  return;
                }
                try {
                  final response = await http.post(
                    Uri.parse('${AppConfig.baseUrl}/api/auth/logout'),
                    headers: {
                      'Content-Type': 'application/json; charset=UTF-8',
                      'Authorization': 'Bearer $token',
                    },
                  );
                  if (response.statusCode == 200) {
                    await prefs.remove('access_token');
                    await prefs.remove('user_id');
                    await prefs.remove('user_name');
                    await prefs.remove('user_email');
                    if (!mounted) return;
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => LoginScreen()),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text(isFilipino
                              ? 'Nabigong mag-logout.'
                              : 'Logout failed.')),
                    );
                  }
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text(isFilipino
                            ? 'May problema sa koneksyon.'
                            : 'Connection error.')),
                  );
                }
              },
            ),
          ],
        ),
      ),
      body: _getBody(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (idx) {
          setState(() {
            _selectedIndex = idx;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.inventory), label: 'My Products'),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  /// Section title widget
  Widget sectionTitle(String title) {
    return Column(
      children: [
        Text(title,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 10),
      ],
    );
  }

  /// Section title with action (e.g., 'See all >')
  Widget sectionTitleWithAction(String title, String actionText) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(actionText, style: TextStyle(color: Colors.blue, fontSize: 14)),
      ],
    );
  }

  /// Grid of categories (shows 4 random categories)
  Widget categoryGrid() {
    // Shuffle and take only 4 categories
    final List<Map<String, dynamic>> shuffled =
        List<Map<String, dynamic>>.from(categories)..shuffle();
    final List<Map<String, dynamic>> displayCategories =
        shuffled.take(4).toList();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 1.4, // slightly wider
        ),
        itemCount: displayCategories.length,
        itemBuilder: (context, index) {
          final cat = displayCategories[index];
          String imagePath = cat['image_path'] != null &&
                  cat['image_path'].toString().isNotEmpty
              ? '${AppConfig.baseUrl}/storage/${cat['image_path']}'
              : 'assets/product_placeholder.png';
          return Card(
            elevation: 2,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CategoryProductsScreen(
                      initialCategoryId: cat['id'],
                      initialCategoryName: cat['name'],
                    ),
                  ),
                );
              }, // You can add navigation or action here
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: imagePath.startsWith('http')
                          ? Image.network(
                              imagePath,
                              height: 160,
                              width: 200,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Image.asset('assets/product_placeholder.png',
                                      height: 60, width: 90, fit: BoxFit.cover),
                            )
                          : Image.asset(imagePath,
                              height: 60, width: 90, fit: BoxFit.cover),
                    ),
                    SizedBox(height: 8),
                    Text(cat['name'] ?? '',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 14),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// =================== PRODUCT ITEM WIDGET ===================
/// Widget for displaying a single product in a horizontal list
class ProductItem extends StatelessWidget {
  final Widget imageWidget;
  final String name;
  final String description;
  final String price;

  const ProductItem({
    super.key,
    required this.imageWidget,
    required this.name,
    required this.description,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    final backgroundModel = Provider.of<Backgroundmodel>(context);
    return SizedBox(
      width: 130,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          imageWidget,
          SizedBox(height: 5),
          Text(name,
              style: TextStyle(fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          Text(description,
              style: TextStyle(fontSize: 12, color: Colors.grey),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          SizedBox(height: 3),
          Row(children: [
            Icon(Icons.star, color: Colors.orange, size: 16),
            Text(" 4.5")
          ]),
          SizedBox(height: 3),
          Text(price,
              style: TextStyle(
                  color: backgroundModel.textColor,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

// =================== CATEGORY ITEM WIDGET ===================
/// Widget for displaying a single category in the grid
class CategoryItem extends StatelessWidget {
  final String title;
  final String imagePath;

  const CategoryItem({super.key, required this.title, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    final isNetwork = imagePath.startsWith('http');
    return SizedBox(
      width: 200,
      child: Column(
        children: [
          isNetwork
              ? Image.network(
                  imagePath,
                  height: 100,
                  width: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Image.asset(
                      'assets/product_placeholder.png',
                      height: 100,
                      width: 200,
                      fit: BoxFit.cover),
                )
              : Image.asset(imagePath,
                  height: 100, width: 200, fit: BoxFit.cover),
          SizedBox(height: 5),
          Text(title,
              style: TextStyle(fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// =================== RECOMMENDED PRODUCT ITEM WIDGET ===================
/// Widget for displaying a recommended product in the grid
class RecommendedProductItem extends StatelessWidget {
  final String imagePath;
  final String price;
  final String? name;
  final String? description;

  const RecommendedProductItem({
    super.key,
    required this.imagePath,
    required this.price,
    this.name,
    this.description,
  });

  @override
  Widget build(BuildContext context) {
    final backgroundModel = Provider.of<Backgroundmodel>(context);
    return SizedBox(
      width: 240, // wider
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          imagePath.startsWith('http')
              ? Image.network(imagePath,
                  height: 170, // higher
                  width: 240, // wider
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Image.asset(
                      'assets/product_placeholder.png',
                      height: 170,
                      width: 240,
                      fit: BoxFit.cover))
              : Image.asset(imagePath,
                  height: 170, width: 240, fit: BoxFit.cover),
          Text(name ?? "Product title",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Text(description ?? "Product description",
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          SizedBox(height: 5),
          Text("30% Off",
              style: TextStyle(
                  color: const Color.fromRGBO(51, 171, 159, 1),
                  fontWeight: FontWeight.bold)),
          SizedBox(height: 5),
          Text(price,
              style: TextStyle(
                  color: backgroundModel.textColor,
                  fontWeight: FontWeight.bold)),
          Text("500 sold",
              style: TextStyle(
                  fontSize: 12, color: const Color.fromARGB(255, 2, 206, 57))),
        ],
      ),
    );
  }
}
// =================== END HOMESCREEN ===================
